import * as saran from './saran.js';
import * as sc from './script.js';
import * as penambahjs from './penambah.js';
import * as produkjs from './produk.js';
import * as hitungjs from './penghitungdata.js';

const ruangbawah = document.getElementById('ruangbawah');
const inputRB = document.getElementById('inputRB');
const inputRBp = document.getElementById('inputRBp');
const closeRBbtn = document.getElementById('closeRBbtn');
const inputRBhp = document.getElementById('inputRBhp');
const ktgharga = document.getElementById('ktgharga');
const inputRBhjp = document.getElementById('inputRBhjp');
const inputRBnp = document.getElementById('inputRBnp');
const inputRBsp = document.getElementById('inputRBsp');
const inputRBjp = document.getElementById('inputRBjp');
const RBcp = document.getElementById('RBcp');
const saveRBbtn = document.getElementById('saveRBbtn');

let idpro = 0;
let toggleKtgHarga = true;
let ktgH = '';
let funcRB;
let prFuncRB;
let ktgH1 = getKtgH1();
const ktgH2 = '#hargakeseluruhan#';

export function getIdPro() {
    return idpro;
}

export function setKtgH(h) {
    ktgH = h;
}

export function getKtgH() {
    return ktgH;
}

export function getKtgH1() {
    return '#hargaperset#';
}
export function openRuangBawah(isi,type,func,prFunc) {
    ruangbawah.style.display = 'flex';
    inputRB.style.display = 'flex';
    inputRB.focus();
    inputRBp.style.display = 'none';funcRB = func; prFuncRB = prFunc;
    inputRB.type = type;
    inputRB.value = isi;
    if (inputRB.value === 'Nama') inputRB.value = '';
    saran.closeSuggestions();
}

export function openRBproduk(isiRB) {
    ruangbawah.style.display = 'flex';
    inputRB.style.display = 'none';
    inputRBp.style.display = 'flex';
    //isiRuangBawah();
    if (typeof isiRB === 'function') {
        isiRB();
    }
    saran.closeSuggestions();
}

async function setKtgHarga() {
    const awa = await hitungjs.getPolaKtgProduk(penambahjs.getNamaDrKolom());
    awa.sort((a,b)=> b.skor-a.skor);
    if(penambahjs.getNamaDrKolom() !== 'Nama' && awa[0].ktgH===ktgH1) {
        toggleKtgHarga = true;
    } else {
        toggleKtgHarga = false;
    }
}

function setToggleKtgHarga() {
    if(toggleKtgHarga) {
        ktgharga.innerHTML = 'Harga per Unit';
        ktgH = ktgH1;
        toggleKtgHarga = false;
    } else {
        ktgharga.innerHTML = 'Harga keseluruhan';
        ktgH = ktgH2;
        toggleKtgHarga = true;
    }
}

export function isiRuangBawah(id,nm,st,jm,hg,pp,ktg,cc) {
    idpro = id || 0;
    inputRBhp.value = hg || '';
    ktgH = ktg|| '';
    inputRBnp.value = nm || '';
    inputRBsp.value = st || '';
    if(Array.isArray(jm)) {
        produkjs.setJumlahPro(jm)
    } else {
        produkjs.setJumlahPro([])
        inputRBjp.value = jm || '';
    }
    inputRBhjp.value = Number(hg)+Number(pp) || '';
    RBcp.value = cc || '';
    if(ktgH === ktgH1) {
        toggleKtgHarga = true;
        setTimeout(setToggleKtgHarga, 100);
    } else if(ktgH === ktgH2) {
        toggleKtgHarga = false;
        setTimeout(setToggleKtgHarga, 100);
    } else {
        setKtgHarga();
        setTimeout(setToggleKtgHarga, 100);
    }
}

export function closeRuangBawah() {
    ruangbawah.style.display = 'none';
    saran.openSuggestions();
}

document.addEventListener('DOMContentLoaded', () => {
    closeRBbtn.addEventListener('click',
        function() {
            closeRuangBawah();
        });
    saveRBbtn.addEventListener('click', function(){
        if(inputRB.style.display === 'none') {
            produkjs.tambahProduk()
            closeRuangBawah();
        } else {
            //penambahjs.isiNama();
            if(typeof funcRB === 'function') {
                funcRB(prFuncRB)
                closeRuangBawah()
            }
        }
    });
    ruangbawah.addEventListener('click',
        function(event) {
            if (event.target === ruangbawah) {
                closeRuangBawah();
            }
        });
    ktgharga.addEventListener('click', setToggleKtgHarga);
});