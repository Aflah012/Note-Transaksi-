import * as widget from './widget.js';
import * as saran from './saran.js';
import * as ruangbawahjs from './ruangbawah.js';
import * as pembayaranjs from './pembayaran.js';
import * as penambahjs from './penambah.js';

const editJumlPro = document.getElementById('editJumlPro');
const listEPro = document.getElementById('listEPro');
let produk = [];
let produkEdit = [];
let jumlahPro = [];

let idproduk = 0;

export function getProdukFormList() {
    return produk;
}

export function setJumlahPro(i) {
    jumlahPro = i||[];
}

export function setPro() {
    lihatProduk(produkEdit)
}

export function resetProduk() {
    produk = [];
    produkEdit = [];
    idproduk = 0;
    jumlahPro = []
}

export function StatusTransaksi() {
    const produks = document.getElementById('produk');
    let item = {ktgT: penambahjs.getKtgT(), produk: getProdukFormList(), pembayaran: pembayaranjs.getPembayaran()};
    let li = widget.buatStatusTransaksi(item);
    produks.appendChild(li);
}

let edit = true;
function editProduk(li,unit) {
    const editPro = document.getElementById('editPro');
    editPro.innerHTML = '';
    if(edit) {
        editPro.style.display = 'flex';
        editPro.style.top = '50%'
        editPro.style.right = '37%'
        let btn = document.createElement('li');
        btn.classList.add('produknama');
        btn.textContent = 'Edit';
        btn.onclick = () => {
            closeEPro()
            ruangbawahjs.openRBproduk(ruangbawahjs.isiRuangBawah(unit.id, unit.nama,unit.satuan,unit.jumlah,unit.harga,unit.profit,unit.ktgH,unit.catatan));
        }
        editPro.appendChild(btn);
        let btn1 = document.createElement('li');
        btn1.classList.add('produknama');
        btn1.textContent = 'Edit Jumlah';
        btn1.onclick = () => {
            editJumlPro.style.display = 'block';
            closeEPro()
            //ruangbawahjs.openRuangBawah('','number',isiJumlah,unit)
            lihatJPro(unit)
        }
        editPro.appendChild(btn1);
        edit = false;
    } else {
        closeEPro()
    }
}
function isiJumlah(unit) {
    ruangbawahjs.isiRuangBawah(unit.id, unit.nama,unit.satuan,unit.jumlah,unit.harga,unit.profit,unit.ktgH,unit.catatan)
    inputRBjp.value = inputRB.value
    tambahProduk();
    lihatJPro(unit)
}
export function closeEPro() {
    editPro.style.display = 'none';
    edit = true;
}

function lihatJPro(unit) {
    listEPro.innerHTML = '';
    if(Array.isArray(unit.jumlah)) {
        unit.jumlah.forEach(item => {
            let liv = liJumPro(item,unit)
            listEPro.appendChild(liv)
        })
    }
    const li1 = document.createElement('li');
    li1.textContent = 'Tambahkan Jumlah';
    li1.onclick = () => ruangbawahjs.openRuangBawah('','number',isiJumlah,unit)
    listEPro.appendChild(li1);
}

export function tambahProduk() {
    let unit = {jml: Number(inputRBjp.value)};
    if(unit.jml !== 0) {
        jumlahPro.push(unit)
    }
    let item = {
        id: ruangbawahjs.getIdPro(),
        nama: inputRBnp.value,
        satuan: inputRBsp.value,
        jumlah: jumlahPro,
        harga: Number(inputRBhp.value),
        profit: Number(inputRBhjp.value)-Number(inputRBhp.value),
        ktgH: ruangbawahjs.getKtgH(),
        catatan: RBcp.value
    };
    
    let same = produkEdit.findIndex(o => o.id === item.id);
    if (same !== -1) {
        produkEdit[same] = item;
    } else {
        produkEdit.push(item);
    }
    lihatProduk(produkEdit);
    ruangbawahjs.isiRuangBawah();
}

export function lihatProduk(produkk) {
    produkEdit = setIdProduk(produkk);
    produk = removeIdProduk(produkEdit);
    const produks = document.getElementById('produk');
    produks.innerHTML = '';
    StatusTransaksi();
    
    produkEdit.forEach(unit => {
        let li = widget.buatListProduk(unit,penambahjs.getKtgT());

        const span = document.createElement('span');
        span.classList.add('closeli');
        span.classList.add('checkpen');
        span.innerHTML = '&times;'
        span.onclick = function(event) {
            event.stopPropagation();
            removeItem(produkEdit, unit.id);
            lihatProduk(produkEdit);
            saran.openSuggestions();
        }
        let syarat = li.querySelector('.produkspace');
        if (syarat) {
            syarat.parentNode.insertBefore(span, syarat);
        }/*
        let ul = document.createElement('ul')
        ul.innerHTML = ''
        ul.style.maxHeight = '100px';
        if(Array.isArray(unit.jumlah)) {
        unit.jumlah.forEach(item => {
            let liv = liJumPro(item,unit)
            ul.appendChild(liv)
        })
        }
        li.appendChild(ul)*/

        li.onclick = function(event) {
            let sya = li.querySelector('li')
            if(event.target !== sya) {
                editProduk(li,unit);
                //ruangbawahjs.openRBproduk(ruangbawahjs.isiRuangBawah(unit.id, unit.nama, unit.satuan, unit.jumlah, unit.harga, unit.profit, unit.ktgH, unit.catatan));
            }
        }

        produks.appendChild(li);
    });

    const li1 = document.createElement('li');
    li1.classList.add('litmb');
    li1.textContent = 'Tambahkan Produk';
    const span = document.createElement('span');
        span.classList.add('btn-saran');
        span.innerHTML = '<img src="icon/edit.png" alt="Icon" width="30" height="30">';
        span.onclick = function(event) {
            event.stopPropagation();
            saran.openSuggestions();
        }
        li1.appendChild(span);
    li1.onclick = () => ruangbawahjs.openRBproduk(ruangbawahjs.isiRuangBawah(''));
    produks.appendChild(li1);
}

function liJumPro(item,unit) {
    let liv = document.createElement('li')
    liv.textContent = item.jml
    liv.onclick = (event) => {
        if(event.target === liv) {
            const index = unit.jumlah.findIndex(it => it.jml === item.jml);
            if (index !== -1) {
                unit.jumlah.splice(index, 1);
            }
            lihatProduk(produkEdit)
            lihatJPro(unit)
        }
    }
    return liv;
}

function removeItem(items, id) {
    const index = items.findIndex(item => item.id === id);
    if (index !== -1) {
        items.splice(index, 1);
    }
}

function setIdProduk(edit) {
    let item = [];
    if(edit) {
    for(let i = 0; i < edit.length; i++) {
        if(edit[i].id === 0||!edit[i].id) {
            idproduk++
            item.push({
                id: idproduk,
                nama: edit[i].nama,
                satuan: edit[i].satuan,
                jumlah: edit[i].jumlah,
                harga: edit[i].harga,
                profit: edit[i].profit,
                ktgH: edit[i].ktgH,
                catatan: edit[i].catatan
            });
        } else {
            item.push(edit[i]);
        }
    }
    }
    return item;
}

function removeIdProduk(edit) {
    let item = [];
    for(let i = 0; i < edit.length; i++) {
        if(edit[i].id > 0||edit[i].id) {
            item.push({nama: edit[i].nama,
                satuan: edit[i].satuan,
                jumlah: edit[i].jumlah,
                harga: edit[i].harga,
                profit: edit[i].profit,
                ktgH: edit[i].ktgH,
                catatan: edit[i].catatan
            });
        } else {
            item.push(edit[i]);
        }
    }
    return item;
}

editJumlPro.addEventListener('click', (event) => {
    if(event.target === editJumlPro) {
        editJumlPro.style.display = 'none';
    }
})