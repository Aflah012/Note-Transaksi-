import * as sc from './script.js';
import * as widget from './widget.js';
import * as penambahjs from './penambah.js';
import * as hitungjs from './penghitungdata.js';
import * as pembayaranjs from './pembayaran.js';
import * as waktujs from './date.js';
import * as produkjs from './produk.js';
import * as ruangbawahjs from './ruangbawah.js';

const suggestions = document.getElementById('saranPen');
const saranRB = document.getElementById('saranRB');
const metodepem = document.getElementById('metodepembayaran');
const jumlahpem = document.getElementById('jumlahpembayaran');

let tampilProduk = [];
let syaratTampilkanSaran = 1;
let syaratTSPaying = 1;
const ktgH1 = ruangbawahjs.getKtgH1();

function klikSaranProduk(unit) {
    ruangbawahjs.setKtgH(unit.ktgH);
    inputRBnp.value = unit.nama;
    inputRBsp.value = unit.satuan;
    if(Array.isArray(unit.jumlah)) {
        produkjs.setJumlahPro(unit.jumlah)
    } else {
        produkjs.setJumlahPro([])
        inputRBjp.value = unit.jumlah || '';
    }
    inputRBhp.value = unit.harga;
    inputRBhjp.value = unit.harga+unit.profit;
    produkjs.tambahProduk();
    openSuggestions();
}

function labelSaranLain() {
    let div = document.createElement('div');
    div.classList.add('date-label');
    div.textContent = 'Saran Lain';
    return div;
}

function aturWidgetSaran(sr,letak,batas) {
    sr.style.top = letak.getBoundingClientRect().bottom+'px';
    sr.style.display = 'flex';
    sr.style.maxHeight = batas+'px';
    sr.innerHTML = '';
}

function syaratSaran(syarat) {
    if(syarat > 1) {
        if(penambahjs.getKtgPenjualan()||penambahjs.getKtgPembelian()) {
            return true;
        }
    }
    return false;
}

export async function openSuggestions() {
    syaratTampilkanSaran++;
    const produks = document.getElementById('produk');
    let syar = syaratSaran(syaratTampilkanSaran);
    if (nama.textContent === 'Nama') {
        aturWidgetSaran(suggestions,nama,180);
        const namali = await hitungjs.getNama();
        namali.sort((a, b) => b.skor - a.skor);
        namali.forEach(item => {
            let li = document.createElement('li');
            li.textContent = item.nama;
            li.style.fontSize = '20px';
            li.onclick = function() {
                nama.innerHTML = item.nama;
                openSuggestions();
                penambahjs.deleteName();
            }
            suggestions.appendChild(li);
        });
    } else if (produk.length < await hitungjs.getPolaJumlahProduk(nama.textContent)&& syar||syar) {
        aturWidgetSaran(suggestions,produks,350);
        tampilProduk = [];
        let produk = produkjs.getProdukFormList();
        syaratTampilkanSaran = 0;
        const produkliPN = await hitungjs.getProdukPerPembeli();
        produkliPN.forEach(item => {
            if (nama.textContent === item.nama) {
                item.produk.sort((a, b) => b.skor - a.skor);
                item.produk.forEach(unit => {
                    let dproduk = produk.find(a=>a.nama === unit.nama && a.catatan === unit.catatan);
                    let tproduk = tampilProduk.find(a=>
                    a.nama === unit.nama&& a.catatan === unit.catatan&& a.satuan === unit.satuan
                    && a.jumlah === unit.jumlah&& a.harga === unit.harga&& a.profit === unit.profit);
                    if (!dproduk && !tproduk) {
                        let li = widget.buatListProduk(unit,penambahjs.getKtgT());
                        li.style.margin = '10px 5px';

                        li.onclick = () => {
                            RBcp.value = unit.catatan;
                            klikSaranProduk(unit);
                        }
                        tampilProduk.push({nama: unit.nama,satuan: unit.satuan,
                            jumlah: unit.jumlah,harga: unit.harga,
                            profit: unit.profit,ktgH: unit.ktgH, catatan: unit.catatan
                        });

                        suggestions.appendChild(li);
                    }
                });
            }
        });

        let div = labelSaranLain();
        suggestions.appendChild(div);
        
        const produkli = await hitungjs.getProduk();
        produkli.sort((a,
            b) => b.skor - a.skor);
        produkli.forEach(unit => {
            let dproduk = produk.find(a=>a.nama === unit.nama/* && a.catatan === unit.catatan*/);
            let tproduk = tampilProduk.find(a=>a.nama === unit.nama
                    && a.satuan === unit.satuan&& a.jumlah === unit.jumlah
                    && a.harga === unit.harga&& a.profit === unit.profit);
            if (!dproduk && !tproduk) {
                let li = widget.buatListProduk(unit,penambahjs.getKtgT());

                li.onclick = function() {
                    klikSaranProduk(unit);
                }
                tampilProduk.push({nama: unit.nama,satuan: unit.satuan,
                            jumlah: unit.jumlah,harga: unit.harga,profit: unit.profit,
                            ktgH: unit.ktgH
                        });
                suggestions.appendChild(li);
            }
        });
    } else {
        closeSuggestions();
        syaratTampilkanSaran = 1;
        setTimeout(bukaSaranPaying, 50);
    }
}

function klikSaranPaying(unit) {
    metodepem.value = unit.metode;
    jumlahpem.value = unit.jumlah;
    tglpem.value = waktujs.datePick();
    wktpem.value = waktujs.timePick();
    pembayaranjs.tambahPembayaran();
    bukaSaranPaying();
}

export async function bukaSaranPaying() {
    syaratTSPaying++;
    const syar = syaratSaran(syaratTSPaying)
    const pembayarann = document.getElementById('pembayaran');
    if(syar) {
        aturWidgetSaran(suggestions,pembayarann,220)
        let produk = produkjs.getProdukFormList();
        let jumlahS = 0;
        produk.forEach(item => {
            let jS;
            if(penambahjs.getKtgT()&&penambahjs.getKtgT()=== 'Beli') {
                jS = item.harga;
            } else {
                jS = item.harga+item.profit;
            }
            if(item.ktgH === ktgH1) {
                jS = jS*widget.setJuml(item);
            }
            jumlahS -= jS;
        });
        let paying = pembayaranjs.getPembayaran();
        paying.forEach(item=>{
            jumlahS+= item.jumlah;
        });
        if(jumlahS > 0) {
            jumlahS = -jumlahS;
        } else {
            jumlahS = Math.abs(jumlahS);
        }
        const lip = (met) => {
            if(met) {
                const umit = {metode: met.metode, jumlah: jumlahS}
                let lip = widget.buatListSaranPaying(umit);
                lip.onclick = () => klikSaranPaying(umit);
                suggestions.appendChild(lip);
            }
        }
        let met;
        syaratTSPaying = 0;
        const payingLiPN = await hitungjs.getPayingPerNama();
        payingLiPN.forEach(item => {
            if (nama.textContent === item.nama) {
                item.pembayaran.sort((a, b) => b.skor - a.skor);
                met = item.pembayaran[0];
                lip(met);
                item.pembayaran.forEach(unit => {
                    let li = widget.buatListSaranPaying(unit);
                        li.onclick = () => {
                            klikSaranPaying(unit);
                        }
                        suggestions.appendChild(li);
                });
            }
        });
        
        let div = labelSaranLain();
        suggestions.appendChild(div);
        
        const payingLi = await hitungjs.getPaying();
        payingLi.sort((a,b) => b.skor - a.skor);
        if(!met) {
        met = payingLi[0];
        lip(met);
        }
        payingLi.forEach(unit => {
                let li = widget.buatListSaranPaying(unit);
                li.onclick = function() {
                    klikSaranPaying(unit);
                }
                suggestions.appendChild(li);
        });
    } else {
        closeSuggestions();
        syaratTSPaying = 1;
    }
}

export async function bukaSaranNamaProduk() {
    const cursorPos = inputRBnp.selectionStart;
        let words = [];
        const text = inputRBnp.value;
        const namaPro = await hitungjs.getNamaProduk();
        const namaProduk = namaPro.sort((a, b) => b.skor - a.skor);
        namaProduk.forEach(item => {
            words.push(item.nama);
        });
        const lastWord = words[words.length - 1].toLowerCase();
        
        let start = cursorPos;
        let end = cursorPos;

        while (start > 0 && /\w/.test(text[start - 1])) {
            start--;
        }

        while (end < text.length && /\w/.test(text[end])) {
            end++;
        }

        const currentWord = text.slice(start, end).toLowerCase();

        const wordList = words.filter(word => word !== lastWord && word.length > 0);
        const wordListB = [...new Set(wordList)];
        const matchingWords = wordList
        .filter(word => word.toLowerCase().startsWith(currentWord) && word.toLowerCase() !== currentWord)
        .sort((a, b) => a.indexOf(currentWord) - b.indexOf(currentWord));

        if (matchingWords.length > 0 /*&& lastWord.length > 0*/) {
            saranRB.innerHTML = matchingWords.map(word => `<li>${word}</li>`).join('');
            saranRB.style.display = 'flex';
            saranRB.style.top = inputRBnp.getBoundingClientRect().top + 'px';
            saranRB.style.maxHeight = '180px';
        } else {
            saranRB.style.display = 'none';
        }

        saranRB.querySelectorAll('li').forEach(item => {
            item.addEventListener('click', () => {
                const selectedWord = item.textContent;
                inputRBnp.value = text.substring(0, start) + selectedWord + text.substring(end);
                inputRBnp.selectionStart = inputRBnp.selectionEnd = start + selectedWord.length;
                inputRBnp.focus();
                saranRB.style.display = 'none';
            });
        });
}
inputRBnp.addEventListener('input', bukaSaranNamaProduk);
export function closeSuggestions() {
    suggestions.style.display = 'none';
}