import * as toastjs from './toast.js'
export function openDatabase(dbName, dbVersion) {
    return new Promise((resolve, reject) => {
        const request = indexedDB.open(dbName, dbVersion);

        request.onupgradeneeded = (event) => {
            const db = event.target.result;
            // Buat object store jika belum ada
            if (!db.objectStoreNames.contains('items')) {
                db.createObjectStore('items', {
                    keyPath: 'id', autoIncrement: true
                });
            }
        };

        request.onsuccess = (event) => {
            const db = event.target.result;
            resolve(db);
        };

        request.onerror = (event) => {
            reject(`Database error: ${event.target.errorCode}`);
        };
    });
}

export function addItem(db, item) {
    return new Promise((resolve, reject) => {
        const transaction = db.transaction(['items'], 'readwrite');
        const objectStore = transaction.objectStore('items');
        const request = objectStore.add(item);

        request.onsuccess = () => {
            resolve();
        };

        request.onerror = (event) => {
            reject(`Add item error: ${event.target.errorCode}`);
        };
    });
}

export function getItem(db, id) {
    return new Promise((resolve, reject) => {
        const transaction = db.transaction(['items'], 'readonly');
        const objectStore = transaction.objectStore('items');
        const request = objectStore.get(id);

        request.onsuccess = (event) => {
            resolve(event.target.result);
        };

        request.onerror = (event) => {
            reject(`Get item error: ${event.target.errorCode}`);
        };
    });
}

export function getAllItems(db) {
    return new Promise((resolve, reject) => {
        const transaction = db.transaction(['items'], 'readonly');
        const objectStore = transaction.objectStore('items');
        const request = objectStore.getAll();

        request.onsuccess = (event) => {
            resolve(event.target.result);
        };

        request.onerror = (event) => {
            reject(`Get all items error: ${event.target.errorCode}`);
        };
    });
}

export function updateItem(db, item) {
    return new Promise((resolve, reject) => {
        const transaction = db.transaction(['items'], 'readwrite');
        const objectStore = transaction.objectStore('items');
        const request = objectStore.put(item);

        request.onsuccess = () => {
            resolve();
        };

        request.onerror = (event) => {
            reject(`Update item error: ${event.target.errorCode}`);
        };
    });
}

export function deleteItem(db, id) {
    return new Promise((resolve, reject) => {
        const transaction = db.transaction(['items'], 'readwrite');
        const objectStore = transaction.objectStore('items');
        const request = objectStore.delete(id);

        request.onsuccess = () => {
            resolve();
        };

        request.onerror = (event) => {
            reject(`Delete item error: ${event.target.errorCode}`);
        };
    });
}

export function resetDataBase(dbName) {
    
    const request = indexedDB.deleteDatabase(dbName);
    
    request.onsuccess = function() {
        console.log('Database berhasil dihapus');
        toastjs.showToast('Database berhasil direset');
    };
    
    request.onerror = function() {
        console.error('Gagal menghapus database');
        toastjs.showToast('Gagal mereset database');
    };
    
    request.onblocked = function() {
        console.warn('Penghapusan database diblokir karena koneksi aktif');
        toastjs.showToast('Penghapusan database diblokir karena koneksi aktif');
    };
}

export function closeDatabase(db) {
    db.close();
}

export async function backupIndexedDB(dbName, dbVersion) {
    try {
        const db = await openDatabase(dbName, dbVersion);
        const items = await getAllItems(db);
        
        const backupData = { items };
        const backupJson = JSON.stringify(backupData);
        downloadBackupFile(backupJson, `${dbName}-backup.json`);
        closeDatabase(db);
    } catch (error) {
        console.error("Backup error:", error);
        toastjs.showToast('Backup error: '+ error);
    }
}

function downloadBackupFile(data, filename) {
    const blob = new Blob([data], {
                    type: 'text/plain'
                });
                const a = document.createElement('a');
                a.href = URL.createObjectURL(blob);
                a.download = filename;
                a.click();
}

export async function restoreIndexedDB(dbName, dbVersion, jsonData) {
    try {
        const db = await openDatabase(dbName, dbVersion);
        const parsedData = JSON.parse(jsonData);

        if (parsedData.items) {
            for (const item of parsedData.items) {
                await updateItem(db, item);
            }
            console.log("Database restore completed.");
            toastjs.showToast('Pemulihan data berhasil.');
        } else {
            console.error("Invalid backup data format.");
            toastjs.showToast('Format cadangan data tidak valid');
        }
        closeDatabase(db);
    } catch (error) {
        console.error("Restore error:", error);
        toastjs.showToast('Pemulihan error: '+ error);
    }
}
/*
function downloadBackupFile(data, filename) {
    const blob = new Blob([data], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    a.click();
    URL.revokeObjectURL(url);
}
*/