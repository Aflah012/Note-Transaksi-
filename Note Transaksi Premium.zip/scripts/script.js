import * as db from './database.js';
import * as tb from './tab.js';
import * as mandat from './keloladata.js';
import * as widget from './widget.js';
import * as saran from './saran.js';
import * as ruangbawah from './ruangbawah.js';
import * as penambahjs from './penambah.js';
import * as toastjs from './toast.js'
import * as akunjs from './akun.js'
import * as statusjs from './status.js'
import * as datajs from './datariset.js'
import * as dialogjs from './dialog.js';

const plus = document.getElementById('plus');
const uploadButton = document.getElementById('uploadButton');
const downloadButton = document.getElementById('downloadButton');
const resetDB = document.getElementById('resetDB');
const uploadInput = document.getElementById('uploadInput');
const buttonHeader = document.getElementById('headerButton');
const drawerDialog = document.getElementById('drawerDialog');
const bukaBackUp = document.getElementById('bukaBackUp');
const backUp = document.getElementById('backUp');
const byteData = document.getElementById('byteData');

const dbName = 'co';
let toggleD = 0;

async function resetData() {
    await db.resetDataBase(dbName);
    dialogjs.closeDialogConfirm();
    setTimeout(mandat.lihat,500);
    tampilkanByteData();
}

function getByteSize(text) {
    const blob = new Blob([text]);
    return blob.size;
}

function formatSizeUnits(bytes) {
    if (bytes >= 1073741824) {
        return (bytes / 1073741824).toFixed(2) + ' GB';
    } else if (bytes >= 1048576) {
        return (bytes / 1048576).toFixed(2) + ' MB';
    } else if (bytes >= 1024) {
        return (bytes / 1024).toFixed(2) + ' KB';
    } else if (bytes > 1) {
        return bytes + ' bytes';
    } else if (bytes === 1) {
        return bytes + ' byte';
    } else {
        return '0 bytes';
    }
}

async function tampilkanByteData() {
    const awal = 'Ukuran data: '
    const data = await db.openDatabase(dbName, 1)
    const items = await db.getAllItems(data);
    byteData.innerHTML = awal+formatSizeUnits(getByteSize(JSON.stringify({items})));
    db.closeDatabase(data);
}

function loadingRestore(items) {
    return getByteSize(items)/25;
}

bukaBackUp.addEventListener('click', function() {
    backUp.style.display = 'flex';
    toggleDrawer();
    tampilkanByteData();
});

backUp.addEventListener('click', function(event) {
    if(event.target === backUp) {
        backUp.style.display = 'none';
    }
});

resetDB.addEventListener('click', () => {
    dialogjs.openDialogConfirm(resetData);
})

uploadButton.addEventListener('click',
        () => {
            uploadInput.click();
        });

    uploadInput.addEventListener('change',
        (event) => {
            const file = event.target.files[0];
            const reader = new FileReader();

            reader.onload = () => {
                const content = reader.result;
                const time = loadingRestore(content);
                db.restoreIndexedDB(dbName, 1, content);
                setTimeout(function() {
                    mandat.lihat();
                    tampilkanByteData();
                    uploadInput.value = '';
                }, Number(time));
            };

            reader.readAsText(file);
        });

    // Download files
downloadButton.addEventListener('click',
        async () => {
            await db.backupIndexedDB(dbName, 1);
});

function toggleDrawer() {
    const drawer = document.getElementById('drawer');
    if(toggleD === 0) {
        drawerDialog.style.display = 'block';
        toggleD = 1;
        setTimeout(function() {
            drawer.classList.toggle('drawer-open');
        }, 100);
    } else if(toggleD === 1){
        drawer.classList.toggle('drawer-open');
        setTimeout(function() {
            drawerDialog.style.display = 'none';
            toggleD = 0;
        }, 150);
    }
}

document.addEventListener('DOMContentLoaded', () => {
    plus.addEventListener('click',function() {
        penambahjs.openPenambah();
    });
    const button = document.querySelectorAll('.button-drawer').forEach(b=> {
        b.addEventListener('click', toggleDrawer)
    })
    buttonHeader.addEventListener('click', function() {
        toggleDrawer();
    });
    drawerDialog.addEventListener('click', function(event) {
        if(event.target === drawerDialog) {
            toggleDrawer();
        }
    })
    tb.activateTabByUrl();
    mandat.lihat();
    window.addEventListener('hashchange',
        tb.activateTabByUrl);
});
