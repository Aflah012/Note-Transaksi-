import * as hitungjs from './penghitungdata.js';
import * as waktujs from './date.js';

const listStatus = document.getElementById('listStatus');
const canvas = document.getElementById('barChart');
const ctx = canvas.getContext('2d');
const scaleC = window.devicePixelRatio;

canvas.width = canvas.offsetWidth * scaleC;
canvas.height = canvas.offsetHeight * scaleC;
ctx.scale(scaleC, scaleC);

let bars = [];

export async function setStatus() {
    listStatus.innerHTML = '';
    
    const profitNow = await hitungjs.getProfit(setWaktu(0));
    const profitKem = await hitungjs.getProfit(setWaktu(1));
    const profitSeb = await hitungjs.getProfit(setWaktu(2));
    const co = [{data: profitNow, label: "Hari Ini"},
                {data: profitKem, label: "Kemarin"},
                {data: profitSeb, label: "Kemarin Lalu"}];

    let day = {k: 'Kemarin', s: 'Hari Ini'}
    let daily = {sb: profitSeb, km: profitKem, sk: profitNow}
    let li = wgStatus(day,daily);

    listStatus.appendChild(li);
    await setWeek();
    
    const mon = await hitungjs.getProfitM(setMonth(0),'');
    const monK = await hitungjs.getProfitM(setMonth(1),setMonth(0));
    const monS = await hitungjs.getProfitM(setMonth(2),setMonth(1));
    
    let chartM = [];
    for(let i = 0; i < mon.length; i++) {
        chartM.push({data: mon[i].profit, label: 'Minggu '+mon[i].tanggal});
    }
    
    const month = {k: 'Bulan Lalu', s: 'Bulan Ini'}
    let monthly = {sb: monS.reduce((s,i)=> s+i.profit,0), km: monK.reduce((s,i)=> s+i.profit,0), sk: mon.reduce((s,i)=> s+i.profit,0)};
    let lim = wgStatus(month,monthly);
    lim.onclick = () => {
        setGrafik(chartM);
    }
    listStatus.appendChild(lim);
    
    const thn = await hitungjs.getProfitY(setYear(0),'');
    const thnK = await hitungjs.getProfitY(setYear(1),setYear(0));
    const thnS = await hitungjs.getProfitY(setYear(2),setYear(1));
    
    let chartY = [];
    for(let i = 0; i < thn.length; i++) {
        chartY.push({data: thn[i].profit, label: waktujs.namaBulanLengkap()[thn[i].tanggal-1]});
    }
    
    const year = {k: 'Tahun Lalu', s: 'Tahun Ini'}
    let yearly = {sb: thnS.reduce((s,i)=> s+i.profit,0), km: thnK.reduce((s,i)=> s+i.profit,0), sk: thn.reduce((s,i)=> s+i.profit,0)};
    let liy = wgStatus(year,yearly);
    liy.onclick = () => {
        setGrafik(chartY);
    }
    setTimeout(()=>{setGrafik(co.reverse())},1000);
    listStatus.appendChild(liy);
}

function setYear(thn) {
    const today = new Date();
    today.setHours(7,0,0,0)
    const year = new Date(today.getFullYear()-thn,1,1);
    return year;
}

function setMonth(bln) {
    const today = new Date();
    today.setHours(7,0,0,0)
    const month = new Date(today.getFullYear(),today.getMonth()-bln,1);
    return month;
}

function getStartOfWeek(date) {
    const dayOfWeek = date.getDay(); // 0: Minggu, 1: Senin, ..., 6: Sabtu
    const diff = dayOfWeek; // Selisih hari untuk mundur ke hari Minggu
    const startOfWeek = new Date(date);
    startOfWeek.setDate(date.getDate() - diff); // Menghitung tanggal awal Minggu ini
    return startOfWeek;
}

async function setWeek() {
    const today = new Date();
    today.setHours(7,0,0,0)
    const awal = getStartOfWeek(today);

    const akhir = new Date(awal);
    akhir.setDate(awal.getDate() + 6);
    
    const awalK = new Date(awal);
    awalK.setDate(awal.getDate()- 7);

    const awalS = new Date(awalK);
    awalS.setDate(awalK.getDate()-7);

    const akhirK = new Date(awalK);
    akhirK.setDate(awalK.getDate()+6);

    const akhirS = new Date(awalS);
    akhirS.setDate(awalS.getDate()+6);

    const w = await hitungjs.getProfitW(awal,akhir);
    const wK = await hitungjs.getProfitW(awalK,akhirK);
    const wS = await hitungjs.getProfitW(awalS,akhirS);
    let chart = [];//console.log(wS.reduce((s,o)=>s + o.profit,0))
    for(let i = 0; i < w.length; i++) {
        chart.push({data: w[i].profit, label: w[i].tanggal});
    }
    
    let week = {k: 'Minggu Lalu', s: 'Minggu Ini'}
    let weekly = {sb: wS.reduce((s,o)=>s + o.profit,0), km: wK.reduce((s,i)=>s+i.profit,0), sk: w.reduce((s,i) =>s+ i.profit,0)};
    //let weekly = {sb: wS, km: wK, sk: w};
    let li = wgStatus(week,weekly);
    li.onclick = () => {
        setGrafik(chart.sort((a,b)=> new Date(a.label) - new Date(b.label)));
    }
    
    listStatus.appendChild(li);
}

function setWaktu(tgl) {
    const hariIni = new Date();
    hariIni.setHours(7,0,0,0)
    const kemarin = new Date(hariIni);
    kemarin.setDate(hariIni.getDate()-tgl);
    const formatTanggal = tanggal => tanggal.toISOString().split('T')[0];
    return formatTanggal(kemarin);
}

function wgStatus(dat,data) {
    let li = document.createElement('li');
    li.classList.add('statusspace');

    let kemper = Math.abs(((data.sb-data.km)/data.sb)*100);
    let divkemarin = document.createElement('div');
    divkemarin.innerHTML = `${dat.k}<br>Rp${data.km.toLocaleString('en-US')}`;
    if(data.sb > data.km) {
        divkemarin.style.color = '#ff0222';
        divkemarin.innerHTML += `<br>▼${kemper.toFixed(2)}%`;
    } else {
        divkemarin.style.color = 'lime';
        if(data.sb === 0) {
            divkemarin.innerHTML += '<br>-';
        } else {
            divkemarin.innerHTML += `<br>▲${kemper.toFixed(2)}%`;
        }
    }
    li.appendChild(divkemarin);
    
    let iniper = Math.abs(((data.km-data.sk)/data.km)*100);
    let divnow = document.createElement('div');
    divnow.innerHTML = `${dat.s}<br>Rp${data.sk.toLocaleString('en-US')}`;
    if(data.km > data.sk) {
        divnow.innerHTML += `<br>▼${iniper.toFixed(2)}%`;
        divnow.style.color = '#ff0222';
    } else {
        divnow.style.color = 'lime';
        if(data.km === 0) {
            divnow.innerHTML += '<br>-';
        } else {
            divnow.innerHTML += `<br>▲${iniper.toFixed(2)}%`;
        }
    }
    li.appendChild(divnow);
    
    return li;
}

function setGrafik(data) {
    const barColor = "#3498db";

    const tooltip = document.getElementById('tooltip');
    
    const canvasWidth = canvas.offsetWidth;
    const canvasHeight = canvas.offsetHeight;
    
    ctx.clearRect(0, 0, canvas.offsetWidth, canvas.offsetHeight);
    let maxValue = Math.max(...data.map(item => item.data));
    let maxValueWidth = ctx.measureText(maxValue).width;
    let padding = maxValueWidth;  
    const maxDataValue = Math.max(...data.map(item => item.data));
    const minBarHeight = 1;
    const minBarWidth = 5;
    const clickZoneHeight = 30;

    const scale = (canvasHeight - padding * 2) / maxDataValue;

    const barWidth = Math.max((canvasWidth - padding * 2) / data.length - padding / 2, minBarWidth);
    bars = [];
    for (let i = 0; i < data.length; i++) {
        const barHeight = Math.max(data[i].data * scale, minBarHeight);
        const x = i * (barWidth + padding / 2) + padding;
        const y = canvasHeight - barHeight - padding;

        bars.push({
            x,
            y,
            width: barWidth,
            height: barHeight,
            value: data[i].data,
            label: data[i].label,
            clickZone: canvasHeight - padding - barHeight // Buat area klik dari atas kolom hingga ke bawah canvas
        });
    
        ctx.fillStyle = barColor;
        ctx.fillRect(x, y, barWidth, barHeight);
    }
}

canvas.addEventListener('click', (e) => {
    const rect = canvas.getBoundingClientRect();
    const mouseX = e.clientX - rect.left;
    const mouseY = e.clientY - rect.top;

    bars.forEach(bar => {
        if (
            mouseX >= bar.x &&
            mouseX <= bar.x + bar.width &&
            (
                (mouseY >= bar.y && mouseY <= bar.y + bar.height) || // Area kolom
                (bar.clickZone > 0 && mouseY >= bar.y - bar.clickZone && mouseY <= bar.y) // Area klik di atas kolom kecil
            )
        ) {
            // Tampilkan tooltip dengan nilai kolom
            tooltip.style.left = `${e.clientX}px`;
            tooltip.style.top = `${e.clientY - 30}px`; // Tooltip di atas klik
            tooltip.innerHTML = `Rp${bar.value.toLocaleString('en-US')+'<br> '+ bar.label}`;
            tooltip.style.display = 'block';
            //setTimeout(() => {}, 3000);
        }
    });
});
setInterval(() => {
    tooltip.style.display = 'none';
},5000);