import * as widget from './widget.js';
import * as saran from './saran.js';
import * as ruangbawahjs from './ruangbawah.js';
import * as waktujs from './date.js';
import * as mandat from './keloladata.js';
import * as pembayaranjs from './pembayaran.js';
import * as dialogjs from './dialog.js';
import * as produkjs from './produk.js';
import * as toastjs from './toast.js'
import * as hitungjs from './penghitungdata.js';

const penambah = document.getElementById('penambah');
const closePnbBtn = document.getElementById('closePenambahBtn');
const nama = document.getElementById('nama');
const hapusnama = document.getElementById('hapusnama');
const saveCat = document.getElementById('saveCat');
const date = document.getElementById('tmbdate');
const time = document.getElementById('tmbtime');
const ktgpembayaran = document.getElementById('ktgpembayaran');
const ktgpenjualan = document.getElementById('ktgpenjualan');
const ktgpembelian = document.getElementById('ktgpembelian');
const kolomPenjualan = document.getElementById('aksipenjualan');
const kolomPembayaran = document.getElementById('aksipembayaran');
const aksiMP = document.getElementById('aksiMP');
const aksiJP = document.getElementById('aksiJP');

let ktgT = '';

export function setKtgT(input) {
    ktgT = input;
}

export function getKtgT() {
    return ktgT;
}

export function setKategori(i) {
    if(i === 'Beli') {
        setKtgPembelian();
        return;
    }
    if(i === 'Jual') {
        setKtgPenjualan();
        return;
    }
    setKtgPembelian();
}

export function deleteName() {
    if(nama.textContent === 'Nama') {
        hapusnama.style.display = 'none'
    } else {
        hapusnama.style.display = 'block'
    }
}

export function isiNama() {
    if (nama.textContent) {
        if(nama.textContent.length > 0) nama.textContent = inputRB.value||'Nama';
        deleteName();
        return;
    }
}

export function displayPenambah() {
    penambah.style.display = 'block';
}

export function displayKtgTn(syarat) {
    if(syarat) {
        ktgpembayaran.style.display = 'block'
    } else {
        ktgpembayaran.style.display = 'none'
        kolomPembayaran.style.display = 'none';
        kolomPenjualan.style.display = 'block';
    }
}

export async function openPenambah() {
    displayPenambah();
    nama.textContent = 'Nama';
    aksiJP.value = '';
    aksiMP.value = 'Uang Tunai';
    timePick();
    datePick();
    deleteName();
    produkjs.resetProduk();
    produkjs.closeEPro();
    pembayaranjs.resetPembayaran();
    produkjs.lihatProduk(produkjs.getProdukFormList());
    pembayaranjs.lihatPembayaran(pembayaranjs.pembayaranedit);
    saran.openSuggestions();
    pembayaranjs.openAndCloseEditPembayaran(false);
    displayKtgTn(true);
    const sta = await hitungjs.getKtgTFD();
    sta.sort((a,b)=> b.skor-a.skor);
    setKategori(sta[0].ktgT);
}

export function closePenambah() {
    penambah.style.display = 'none';
    saran.closeSuggestions();
}

export function datePick() {
    const date = document.getElementById('tmbdate');
    date.value = waktujs.datePick();
}

export function timePick() {
    const time = document.getElementById('tmbtime');
    time.value = waktujs.timePick();
}

export function setWaktu(jam, tanggal) {
    time.value = jam;
    date.value = tanggal;
}

export function jam() {
    return time.value;
}

export function tanggal() {
    return date.value;
}

document.addEventListener('DOMContentLoaded', () => {
    
    closePenambah();
    deleteName();
    closePnbBtn.addEventListener('click',
        closePenambah);
        
    nama.addEventListener('click',
        () => {
            ruangbawahjs.openRuangBawah(nama.textContent,'text',isiNama);
        });
    
    hapusnama.addEventListener('click', function() {
        nama.textContent = 'Nama';
        deleteName();
        saran.openSuggestions();
    });
});

export function getNamaDrKolom() {
    return nama.innerText;
}

export function setKtgPenjualan() {
    ktgpenjualan.querySelector('span').style.visibility = 'visible';
    ktgpembayaran.querySelector('span').style.visibility = 'hidden';
    ktgpembelian.querySelector('span').style.visibility = 'hidden';
    kolomPenjualan.style.display = 'block';
    kolomPembayaran.style.display = 'none';
    setKtgT('Jual');
    produkjs.setPro()
}

function setKtgPembayaran() {
    ktgpenjualan.querySelector('span').style.visibility = 'hidden';
    ktgpembayaran.querySelector('span').style.visibility = 'visible';
    ktgpembelian.querySelector('span').style.visibility = 'hidden';
    kolomPenjualan.style.display = 'none';
    kolomPembayaran.style.display = 'block';
    saran.openSuggestions();
    if(pembayaranjs.getStatusEP()) {
        pembayaranjs.openAndCloseEditPembayaran(false);
    }
    aksiJP.focus();
}

export function setKtgPembelian() {
    ktgpembelian.querySelector('span').style.visibility = 'visible';
    ktgpenjualan.querySelector('span').style.visibility = 'hidden';
    ktgpembayaran.querySelector('span').style.visibility = 'hidden';
    kolomPenjualan.style.display = 'block';
    kolomPembayaran.style.display = 'none';
    setKtgT('Beli');
    produkjs.setPro()
}

export function getKtgPenjualan() {
    if(ktgpenjualan.querySelector('span').style.visibility === 'hidden') {
        return false;
    }
    return true;
}

export function getKtgPembelian() {
    if(ktgpembelian.querySelector('span').style.visibility === 'hidden') {
        return false;
    }
    return true;
}

saveCat.addEventListener('click', function() {
    if(getKtgPenjualan()|| ktgT === 'Beli') {
        if(getNamaDrKolom() !== 'Nama'|| !getNamaDrKolom()) {
            mandat.tambahData(getNamaDrKolom(), getKtgT(), tanggal(), jam(), produkjs.getProdukFormList(), pembayaranjs.getPembayaran());
            closePenambah();
            toastjs.showToast('Data berhasil disimpan')
        } else {
            toastjs.showToast('Nama belum diisi!')
        }
    } else {
        if(getNamaDrKolom() && getNamaDrKolom() !== 'Nama' && aksiMP.value) {
            mandat.bayarSejumlahTransaksi(getNamaDrKolom(), aksiMP.value, Number(aksiJP.value), tanggal(), jam(), 50);
            closePenambah();
            toastjs.showToast('Data berhasil disimpan')
        }
        if(!getNamaDrKolom() || getNamaDrKolom() === 'Nama') {
            toastjs.showToast('Nama belum diisi!');
        }
        if(!aksiMP.value) {
            toastjs.showToast('Metode Pembayaran belum diisi!')
        }
    }
    
})

ktgpenjualan.addEventListener('click', function() {
    setKtgPenjualan();
});

ktgpembayaran.addEventListener('click', setKtgPembayaran);
ktgpembelian.addEventListener('click', setKtgPembelian);

penambah.addEventListener('click', (event) => {
    const suggestions = document.getElementById('saranPen');
    if(event.target !== suggestions && event.target !== hapusnama && event.target !== ktgpembayaran &&
        event.target !== ktgpembelian && event.target !== ktgpenjualan) {
        saran.closeSuggestions()
    }
})