import * as db from './database.js';
import * as widget from './widget.js';
import * as ruangbawahjs from './ruangbawah.js';

const dbName = 'co';
const ktgH1 = ruangbawahjs.getKtgH1();

export async function getNama() {
    const data = await db.openDatabase(dbName, 1);
    const items = await db.getAllItems(data);
    let namali = [];
    items.forEach(item => {
        let namada = namali.findIndex(a => a.nama === item.nama);
        if (namada !== -1) {
            namali[namada].nama = item.nama;
            namali[namada].skor++;
        } else {
            namali.push({
                nama: item.nama, skor: 1
            });
        }
    });
    db.closeDatabase(data);
    return namali;
}

export async function getKtgTFD() {
    const data = await db.openDatabase(dbName, 1);
    const items = await db.getAllItems(data);
    let na = [];
    items.forEach(item => {
        let n = na.findIndex(a => a.ktgT === item.ktgT);
        if (n !== -1) {
            na[n].ktgT = item.ktgT;
            na[n].skor++;
        } else {
            na.push({
                ktgT: item.ktgT, skor: 1
            });
        }
    });
    db.closeDatabase(data);
    return na;
}

export async function getPolaJumlahProduk(getnama) {
    const data = await db.openDatabase(dbName,1);
    const items = await db.getAllItems(data);
    let jumlahProduk = 0;
    let skor = 0;
    items.forEach(item => {
        if (getnama === item.nama) {
            jumlahProduk += item.produk.length;
            skor++;
        }
    });
    if (jumlahProduk/skor === 0) {
        return 0;
    }
    db.closeDatabase(data);
    return jumlahProduk / skor;
}

export async function getPolaKtgProduk(getnama) {
    const data = await db.openDatabase(dbName,1);
    const items = await db.getAllItems(data);
    let Pola = [];
    let skor = 0;
    items.forEach(item => {
        if (getnama === item.nama) {
            item.produk.forEach(prod => {
                let pro = Pola.findIndex(a=>a.ktgH === prod.ktgH);
            if (pro !== -1) {
                Pola[pro].ktgH = prod.ktgH;
                Pola[pro].skor++;
            } else {
                Pola.push({
                    ktgH: prod.ktgH,
                    skor: 1
                });
            }
        });
        }
    });
    db.closeDatabase(data);
    return Pola;
}

export async function getProduk() {
    const data = await db.openDatabase(dbName,1);
    const items = await db.getAllItems(data);
    let produkli = {};
    items.forEach(item => {
        item.produk.forEach(prod => {
            const key = `${prod.nama}-${prod.satuan}-${prod.jumlah}-${prod.harga}-${prod.profit}`;
            if (produkli[key]) {
                produkli[key].skor++;
            } else {
                produkli[key] = {
                    nama: prod.nama,
                    satuan: prod.satuan,
                    jumlah: prod.jumlah,
                    harga: prod.harga,
                    profit: prod.profit,
                    ktgH: prod.ktgH,
                    skor: 1
                };
            }
        });
    });
    db.closeDatabase(data);
    return Object.values(produkli);
}

export async function getProdukPerPembeli() {
    const data = await db.openDatabase(dbName, 1);
    const items = await db.getAllItems(data);
    const produkPerPembeli = {};

    items.forEach(item => {
        if (!produkPerPembeli[item.nama]) {
            produkPerPembeli[item.nama] = {};
        }
        item.produk.forEach(prod => {
            const key = `${prod.nama}-${prod.satuan}-${prod.jumlah}-${prod.harga}-${prod.profit}-${prod.catatan}`;
            if (produkPerPembeli[item.nama][key]) {
                produkPerPembeli[item.nama][key].skor++;
            } else {
                produkPerPembeli[item.nama][key] = {
                    nama: prod.nama,
                    satuan: prod.satuan,
                    jumlah: prod.jumlah,
                    harga: prod.harga,
                    profit: prod.profit,
                    ktgH: prod.ktgH,
                    catatan: prod.catatan,
                    skor: 1 // Jumlah pencatatan
                };
            }
        });
    });
    db.closeDatabase(data);
    return Object.entries(produkPerPembeli).map(([nama,
        produk]) => ({
        nama,
        produk: Object.values(produk)
    }));
}

export async function getNamaProduk() {
    const data = await db.openDatabase(dbName,1);
    const items = await db.getAllItems(data);
    let produkli = {};
    items.forEach(item => {
        item.produk.forEach(prod => {
            const key = prod.nama;
            if (produkli[key]) {
                produkli[key].skor++;
            } else {
                produkli[key] = {
                    nama: prod.nama,
                    skor: 1
                };
            }
        });
    });
    db.closeDatabase(data);
    return Object.values(produkli);
}

function hitungProdukPerPembeliDuaBulanTerakhir(transaksi) {
    const produkPerPembeli = {};

    // Ambil tanggal hari ini
    const today = new Date();

    // Kurangi dua bulan dari tanggal hari ini
    const twoMonthsAgo = new Date(today);
    twoMonthsAgo.setMonth(today.getMonth() - 2);

    // Filter transaksi yang terjadi dalam dua bulan terakhir
    const transaksiDuaBulanTerakhir = transaksi.filter(item => {
        const tanggalTransaksi = new Date(item.tanggal);
        return tanggalTransaksi >= twoMonthsAgo && tanggalTransaksi <= today;
    });

    transaksiDuaBulanTerakhir.forEach(item => {
        // Buat entri baru untuk pembeli jika belum ada
        if (!produkPerPembeli[item.nama]) {
            produkPerPembeli[item.nama] = {};
        }

        // Iterasi produk dalam transaksi
        item.produk.forEach(prod => {
            // Buat kunci unik berdasarkan detail produk
            const key = `${prod.nama}-${prod.satuan}-${prod.harga}-${prod.profit}-${prod.catatan}`;

            if (produkPerPembeli[item.nama][key]) {
                // Jika produk dengan detail ini sudah ada, tambahkan jumlah
                produkPerPembeli[item.nama][key].jumlah += prod.jumlah;
                produkPerPembeli[item.nama][key].count++;
            } else {
                // Jika produk dengan detail ini belum ada, buat entry baru
                produkPerPembeli[item.nama][key] = {
                    nama: prod.nama,
                    satuan: prod.satuan,
                    harga: prod.harga,
                    profit: prod.profit,
                    catatan: prod.catatan,
                    jumlah: prod.jumlah,
                    count: 1 // Jumlah pencatatan
                };
            }
        });
    });
    db.closeDatabase(data);
    // Mengubah objek produkPerPembeli menjadi array
    return Object.entries(produkPerPembeli).map(([pembeli,
        produk]) => ({
        pembeli,
        produk: Object.values(produk)
    }));
}

export async function getPaying() {
    const data = await db.openDatabase(dbName,1);
    const items = await db.getAllItems(data);
    let payingLi = {};
    items.forEach(item => {
        item.pembayaran.forEach(pay => {
            const key = `${pay.metode}-${pay.jumlah}`;
            if (payingLi[key]) {
                payingLi[key].skor++;
            } else {
                payingLi[key] = {
                    metode: pay.metode,
                    jumlah: pay.jumlah,
                    skor: 1
                };
            }
        });
    });
    db.closeDatabase(data);
    return Object.values(payingLi);
}

export async function getPayingPerNama() {
    const data = await db.openDatabase(dbName, 1);
    const items = await db.getAllItems(data);
    const payingPerNama = {};

    items.forEach(item => {
        if (!payingPerNama[item.nama]) {
            payingPerNama[item.nama] = {};
        }
        item.pembayaran.forEach(unit => {
            const key = `${unit.metode}-${unit.jumlah}`;
            if (payingPerNama[item.nama][key]) {
                payingPerNama[item.nama][key].skor++;
            } else {
                payingPerNama[item.nama][key] = {
                    metode: unit.metode,
                    jumlah: unit.jumlah,
                    skor: 1
                };
            }
        });
    });
    db.closeDatabase(data);
    return Object.entries(payingPerNama).map(([nama,
        pembayaran]) => ({
        nama,
        pembayaran: Object.values(pembayaran)
    }));
}

export async function lihatStatusAkun() {
    const name = await getNama();
    const data = await db.openDatabase(dbName, 1);
    const items = await db.getAllItems(data);
    
    let save = []
    name.sort((a,b)=> b.skor-a.skor);
    name.forEach(item => {
        let jumlahS = 0;
        items.forEach(pro=> {
            if(pro.nama === item.nama) {
                pro.produk.forEach(unit=>{
                    let jS;
                    if(pro.ktgT === 'Beli') {
                        jS = unit.harga;
                    } else {
                        jS = unit.harga+unit.profit;
                    }
                    if(unit.ktgH === ktgH1) {
                        jS = jS*widget.setJuml(unit);
                    }
                    jumlahS -= jS;
                })
            }
            if(pro.nama === item.nama) {
                pro.pembayaran.forEach(unit=>{
                    jumlahS += unit.jumlah;
                })
            }
        })
        save.push({nama: item.nama, uang: jumlahS});
    })
    db.closeDatabase(data);
    return save;
}
export async function getProfit(tgl) {
    const data = await db.openDatabase(dbName, 1);
    const items = await db.getAllItems(data);
    let proftli = 0;
    items.forEach(item => {
        if(item.tanggal === tgl) {
            item.produk.forEach(unit => {
                let P = unit.profit;
                if(unit.ktgH === ktgH1) {
                    P = P*widget.setJuml(unit);
                }
                proftli += P;
            })
        }
    });
    db.closeDatabase(data);
    return proftli;
}

export async function getProfitW(tgl, akhir) {
    const data = await db.openDatabase(dbName, 1);
    const items = await db.getAllItems(data);
    let proftli = {};
    items.forEach(item => {
        const waktu = new Date(item.tanggal);
        if(waktu >= tgl && waktu <= akhir) {
            item.produk.forEach(unit => {
                let P = unit.profit;
                if(unit.ktgH === ktgH1) {
                    P = P*widget.setJuml(unit);
                }
                if(proftli[item.tanggal]) {
                    proftli[item.tanggal].profit +=P;
                } else {
                    proftli[item.tanggal] = {
                        tanggal: item.tanggal,
                        profit: P
                    }
                }
            });
        } else if(waktu >= tgl && akhir === '') {
            item.produk.forEach(unit => {
                let P = unit.profit;
                if(unit.ktgH === ktgH1) {
                    P = P*widget.setJuml(unit);
                }
                if(proftli[item.tanggal]) {
                    proftli[item.tanggal].profit +=P;
                } else {
                    proftli[item.tanggal] = {
                        tanggal: item.tanggal,
                        profit: P
                    }
                }
            });
        }
    });
    db.closeDatabase(data);
    return Object.values(proftli);
}

export async function getProfitY(tgl, akhir) {
    const data = await db.openDatabase(dbName, 1);
    const items = await db.getAllItems(data);
    let proftli = {};
    items.forEach(item => {
        const waktu = new Date(item.tanggal);
        const month = getMonthNumber(waktu);
        if(waktu >= tgl && waktu < akhir) {
            item.produk.forEach(unit => {
                let P = unit.profit;
                if(unit.ktgH === ktgH1) {
                    P = P*widget.setJuml(unit);
                }
                if(proftli[month]) {
                    proftli[month].profit +=P;
                } else {
                    proftli[month] = {
                        tanggal: month,
                        profit: P
                    }
                }
            });
        } else if(waktu >= tgl && akhir === '') {
            item.produk.forEach(unit => {
                let P = unit.profit;
                if(unit.ktgH === ktgH1) {
                    P = P*widget.setJuml(unit);
                }
                if(proftli[month]) {
                    proftli[month].profit +=P;
                } else {
                    proftli[month] = {
                        tanggal: month,
                        profit: P
                    }
                }
            });
        }
    });
    db.closeDatabase(data);
    return Object.values(proftli);
}
function getMonthNumber(date) {
    return date.getMonth() + 1;
}
export async function getProfitM(tgl, akhir) {
    const data = await db.openDatabase(dbName, 1);
    const items = await db.getAllItems(data);
    let proftli = {};

    items.forEach(item => {
        const waktu = new Date(item.tanggal);
        const weekNumber = getWeekNumber(waktu); // Mendapatkan nomor minggu dari tanggal transaksi

        if (waktu >= tgl && waktu < akhir) {
            item.produk.forEach(unit => {
                let P = unit.profit;
                if(unit.ktgH === ktgH1) {
                    P = P * widget.setJuml(unit); // Kalkulasi jika sesuai dengan kategori
                }

                if (proftli[weekNumber]) {
                    proftli[weekNumber].profit += P;
                } else {
                    proftli[weekNumber] = {
                        week: weekNumber,
                        profit: P
                    };
                }
            });
        } else if(waktu >= tgl && akhir === '') {
            item.produk.forEach(unit => {
                let P = unit.profit;
                if(unit.ktgH === ktgH1) {
                    P = P*widget.setJuml(unit);
                }
                if(proftli[weekNumber]) {
                    proftli[weekNumber].profit +=P;
                } else {
                    proftli[weekNumber] = {
                        tanggal: weekNumber,
                        profit: P
                    }
                }
            });
        }
    });

    db.closeDatabase(data);
    return Object.values(proftli);
}

function getWeekNumber(date) {
    const startOfMonth = new Date(date.getFullYear(), date.getMonth(), 1);
    const pastDaysOfMonth = (date - startOfMonth) / 86400000;
    return Math.ceil((pastDaysOfMonth + startOfMonth.getDay()) / 7);
}