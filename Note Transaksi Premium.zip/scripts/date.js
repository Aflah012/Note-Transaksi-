export class Tanggal {
    getDate() {
        const now = new Date();
        const date = String(now.getDate()).padStart(2, '0');
        return date;
    }
    
    getMonth() {
        const now = new Date();
        const month = String(now.getMonth()+1).padStart(2, '0');
        return month;
    }
    
    getYear() {
        const now = new Date();
        const year = now.getFullYear();
        return year;
    }
    
    getDay() {
        const now = new Date();
        const days = ['Minggu', 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu'];
        return days[now.getDay()];
    }
    
    getHour() {
        const now = new Date();
        const hour = String(now.getHours()).padStart(2, '0');
        return hour;
    }
    
    getMinute() {
        const now = new Date();
        const menute = String(now.getMinutes()).padStart(2, '0');
        return menute;
    }
    
    getSecond() {
        const now = new Date();
        const second = String(now.getSeconds()).padStart(2, '0');
        return second;
    }
}

export function datePick() {
    let dat = new Tanggal();
    const date = `${dat.getYear()}-${dat.getMonth()}-${dat.getDate()}`
    return date;
}

export function timePick() {
    let dat = new Tanggal();
    const time = `${dat.getHour()}:${dat.getMinute()}`;
    return time;
}

const tgl = new Tanggal();
export function getMonth() {
    return tgl.getMonth();
}

export function getDate() {
    return tgl.getDate();
}

export function getYear() {
    return tgl.getYear();
}

export function namaBulanLengkap() {
    const nama = ['Januari','Februari','Maret','April','Mei','Juni','Juli'
                ,'Agustus','September','Oktober','November','Desember'];
    return nama;
}

export function namaBulanSingkat() {
    const nama = ['Jan', 'Feb', 'Mar', 'Apr', 'Mei', 'Jun', 'Jul', 'Agu', 'Sep', 'Okt', 'Nov', 'Des'];
    return nama;
}

export function getDayName(dateStr) {
    const date = new Date(dateStr);
    return date.toLocaleDateString('id-ID', {
        weekday: 'long'
    });
}