import * as hitungjs from './penghitungdata.js';

const listData = document.getElementById('listData');
const dataCat = document.getElementById('dataCat');
const dataBtn = document.getElementById('dataBtn');

let toggleDC = true;

async function liData(nm) {
    listData.innerHTML = '';
    if(nm === 'Nama') {
        const namali = await hitungjs.getNama();
        let i = 0;
        let persen = namali.reduce((sum,u)=>sum+u.skor,0);
        namali.sort((a, b) => b.skor - a.skor);
        namali.forEach(item => {i++;
            let li = document.createElement('li');
            li.classList.add('produkspace');
            li.style.fontSize = '20px';
            
            let div = document.createElement('div');
            div.textContent = `${i}. ${item.nama}`;
            li.appendChild(div);
            
            let div1 = document.createElement('div');
            div1.textContent = `${(100/persen*item.skor).toFixed(1)}% ${item.skor}X`;
            li.appendChild(div1);
            
            listData.appendChild(li);
        });
    }
}

function displayDatCat() {
    dataCat.style.top = dataBtn.getBoundingClientRect().bottom+'px';
    dataCat.style.right = '42%';
    if(toggleDC) {
        dataCat.style.display = 'block';
        toggleDC = false;
    } else {
        dataCat.style.display = 'none';
        toggleDC = true;
    }
    openCat();
}

function openCat() {
    dataCat.innerHTML = '';
    let li = document.createElement('li');
    li.textContent = 'Nama';
    li.onclick = () => {
        dataBtn.textContent = li.textContent;
        displayDatCat();
        liData('Nama');
    }
    dataCat.appendChild(li);
}

dataBtn.addEventListener('click',displayDatCat);