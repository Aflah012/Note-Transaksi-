import * as db from './database.js';
import * as sc from './script.js';
import * as widget from './widget.js';
import * as penambahjs from './penambah.js';
import * as dialogjs from './dialog.js';
import * as pembayaranjs from './pembayaran.js';
import * as waktujs from './date.js';
import * as akunjs from './akun.js'
import * as ruangbawahjs from './ruangbawah.js';
import * as statusjs from './status.js';

export const dbName = 'co';
let previousDate = '';
let monthFilter = parseInt(waktujs.getMonth());
let yearFilter = parseInt(waktujs.getYear());
const nbFilter = waktujs.namaBulanLengkap();

const ktgH1 = ruangbawahjs.getKtgH1();

export async function tambahData(nn, ktg, tt, cc, dd, pp) {
    const id = dialogjs.getTransaksiId();
    if (id) {
        const data = await db.openDatabase(dbName, 1);
        let item = await db.getItem(data, id);
        if (item) {
            item.nama = nn;
            item.ktgT = ktg;
            item.tanggal = tt;
            item.waktu = cc;
            item.produk = dd;
            item.pembayaran = pp;
            await db.updateItem(data, item);
        }
        [nn, ktg, tt, cc, dd] = ['', '', '', '', ''];
        db.closeDatabase(data);
        dialogjs.setTransaksiId(0);
    } else if (nn && tt && cc && dd) {
        const data = await db.openDatabase(dbName, 1);
        await db.addItem(data, {
            nama: nn, ktgT: ktg, tanggal: tt, waktu: cc, produk: dd, pembayaran: pp
        });
        [nn, ktg, tt, cc, dd] = ['', '', '', '', ''];
        db.closeDatabase(data);
    }
    lihat();
}

export async function menghapus() {
    const id = dialogjs.getTransaksiId();
    if (!id) {
        return;
    }
    const data = await db.openDatabase(dbName, 1);
    let valueId = Number(id)
    await db.deleteItem(data, valueId);
    db.closeDatabase(data);
    dialogjs.closeDialogConfirm();
    lihat();
}

function filterList(input) {
    if(input === -1) {
        monthFilter--;
    } else if(input === 1) {
        monthFilter++;
    }
    if(monthFilter < 1) {
        monthFilter = 12;
        yearFilter--;
    } else if(monthFilter > 12){
        monthFilter = 1;
        yearFilter++;
    }
    lihat();
}

export async function lihat() {
    const c = document.getElementById('urutan');
    const data = await db.openDatabase(dbName, 1);
    const items = await db.getAllItems(data);
    c.innerHTML = '';
    
    let divfilter = document.querySelector('.list-data-filter');
    divfilter.innerHTML = `<span class="back"><</span>
    <div>${nbFilter[monthFilter-1]+', '+yearFilter}</div>
    <span class="next">></span>`;
    
    let spanback = divfilter.querySelector('.back');
    spanback.addEventListener('click', function() {
        filterList(-1);
    });
    let spannext = divfilter.querySelector('.next');
    spannext.addEventListener('click', function() {
        filterList(1);
    });
    
    const itemsFiltered = items.filter(item => {
        const [transYear, transMonth] = item.tanggal.split('-');
        return parseInt(transYear) === yearFilter && parseInt(transMonth) === monthFilter;
    });
    itemsFiltered.sort((a, b) => new Date(`${b.tanggal}T${b.waktu}:00`)-new Date(`${a.tanggal}T${a.waktu}:00`))
    itemsFiltered.forEach(item => {
        let [thn, bln, tgl] = item.tanggal.split('-');
        let bulan = waktujs.namaBulanSingkat();
        const currentDate = bulan[bln-1]+' '+tgl;
        const dayName = waktujs.getDayName(item.tanggal);

        if (currentDate !== previousDate) {
            const dateLabel = document.createElement('div');
            dateLabel.className = 'date-label';
            dateLabel.textContent = `${dayName}, ${currentDate}`;
            c.appendChild(dateLabel);
            previousDate = currentDate;
        }
        
        let ttt = konversiTanggal(item);
        let time = ttt+' '+item.waktu;
        
        let li = widget.listDataTransaksi(item);

        li.onclick = () => dialogjs.openDialog(item.id, item.ktgT, item.nama, time, item.produk, item.pembayaran);
        
        c.appendChild(li);
    });
    db.closeDatabase(data);
    akunjs.lihatAkun();
}

export function konversiTanggal(item) {
    let [t1,
        t2,
        t3] = item.tanggal.split('-');
    let ttt = t3+'/'+t2+'/'+t1;
    return ttt;
}

export async function bayarSejumlahTransaksi(nama, mtd, uang, tgl, wkt, batas) {
    const data = await db.openDatabase(dbName, 1);
    const items = await db.getAllItems(data);
    
    items.sort((a, b) => new Date(`${b.tanggal}T${b.waktu}:00`) - new Date(`${a.tanggal}T${a.waktu}:00`));
    let selectedItems = items.filter(item => item.nama === nama).slice(0, batas);
    selectedItems.reverse();
    
    let uangLebih = [];
    
    const getTotalP = (item) => {
        return item.produk.reduce((sum, unit) => {
            let su; 
            if(item.ktgT === 'Beli') {
                su = unit.harga;
            } else {
                su = unit.harga + unit.profit;
            }
            if(unit.ktgH === ktgH1) {
                su = su*widget.setJuml(unit);
            }
            return sum += su;
        }, 0);
    }
    
    const hitungUtang = (item) => {
        const totalProduk = getTotalP(item);
        const totalPembayaran = item.pembayaran.reduce((sum, payment) => sum + payment.jumlah, 0);
        return Math.max(0, totalProduk - totalPembayaran);
    };
    const tulisData = (item, metod, juml,tangg,wakt) => {
        const eNP = item.pembayaran.find(p => p.metode === metod
            && p.jumlah > 0 && p.tanggal === tangg && p.waktu === wakt);
        if (eNP) {
            eNP.jumlah += juml;
        } else {
            item.pembayaran.push({
                metode: metod,
                jumlah: juml,
                tanggal: tangg,
                waktu: wakt
            });
        }
    }
    const bayarUtang = (item, jumlahBayar, metodeBayar,tangg,wakt) => {
        const utangAwal = hitungUtang(item);
        const jumlahDibayar = Math.min(jumlahBayar, utangAwal);
        if (jumlahDibayar > 0) {
            tulisData(item,metodeBayar,jumlahDibayar,tangg,wakt);
        }
        return jumlahDibayar;
    };
    const kurangiUangLebih = (jumlah) => {
        let sisaKurang = Math.abs(jumlah);
        let uangLebihBaru = [];
        for (const payment of uangLebih) {
            if (sisaKurang >= payment.jumlah) {
                uangLebihBaru.push({metode: payment.metode, jumlah: payment.jumlah - sisaKurang, tanggal: payment.tanggal, waktu: payment.waktu});
                sisaKurang -= payment.jumlah;
            } else if (sisaKurang > 0) {
                uangLebihBaru.push({metode: payment.metode, jumlah: payment.jumlah - sisaKurang, tanggal: payment.tanggal, waktu: payment.waktu});
                sisaKurang = 0;
            } else {
                uangLebihBaru.push(payment);
            }
        }
        uangLebih = uangLebihBaru;
        return Math.max(0, -jumlah - Math.abs(jumlah) + sisaKurang);
    };
    for (const item of selectedItems) {
        const totalProduk = getTotalP(item);
        const totalPembayaran = item.pembayaran.reduce((sum, payment) => sum + payment.jumlah, 0);
        if (totalPembayaran > totalProduk) {
            const lebih = totalPembayaran - totalProduk;
            let sisaLebih = lebih;
            for (let i = item.pembayaran.length - 1; i >= 0 && sisaLebih > 0; i--) {
                const payment = item.pembayaran[i];
                if (payment.jumlah > 0) {
                    const jumlahDiambil = Math.min(payment.jumlah, sisaLebih);
                    if(uang < 0) {
                        tulisData(item,payment.metode,-jumlahDiambil,tgl,wkt);
                    } else {
                        tulisData(item,payment.metode,-jumlahDiambil,payment.tanggal,payment.waktu);
                    }
                    sisaLebih -= jumlahDiambil;
                    uangLebih.push({metode: payment.metode, jumlah: jumlahDiambil, tanggal: payment.tanggal, waktu: payment.waktu});
                }
            }
        }
    }
    if (uang < 0) {
        uang = kurangiUangLebih(uang);
    }
    let indexTransaksi = 0;
    while ((uang > 0 || uangLebih.length > 0) && indexTransaksi < selectedItems.length) {
        const item = selectedItems[indexTransaksi];
        let utang = hitungUtang(item);
        if (uang > 0 && utang > 0) {
            const dibayar = bayarUtang(item, uang, mtd,tgl,wkt);
            uang -= dibayar;
            utang -= dibayar;
        }
        while (utang > 0 && uangLebih.length > 0) {
            const payment = uangLebih.shift();
            const dibayar = bayarUtang(item, payment.jumlah, payment.metode,payment.tanggal,payment.waktu);
            utang -= dibayar;
            if (payment.jumlah > dibayar) {
                uangLebih.unshift({metode: payment.metode, jumlah: payment.jumlah - dibayar,tanggal: payment.tanggal,waktu:payment.waktu});
            }
        }
        await db.updateItem(data, item);
        indexTransaksi++;
    }
    // Menangani sisa uang lebih
    if (uang > 0 || uangLebih.length > 0) {
        const lastItem = selectedItems[selectedItems.length - 1];
        if (uang > 0) {
            tulisData(lastItem,mtd,uang,tgl,wkt);
        }
        for (const payment of uangLebih) {
            if(payment.jumlah > 0) {
                tulisData(lastItem,payment.metode,payment.jumlah,payment.tanggal,payment.waktu);
            }
        }
        await db.updateItem(data, lastItem);
    }
    await lihat();
    db.closeDatabase(data);
}