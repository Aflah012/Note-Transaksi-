import * as statusjs from './status.js'

const tabButtons = document.querySelectorAll('.tab-button');
const tab1 = 'home';
const tab2 = 'akun';
const tab3 = 'data';
const tab4 = 'status';

export function activateTabByUrl() {
    const hash = window.location.hash;
    document.getElementById(tab1).style.display = 'none';
    document.getElementById(tab2).style.display = 'none';
    document.getElementById(tab3).style.display = 'none';
    document.getElementById(tab4).style.display = 'none';

    if (hash) {
        //hash = defaultTabHash;
        //window.location.hash = '#home'; // Set default hash ke URL


        tabButtons.forEach(tab => {
            tab.classList.remove('active');
            if (tab.getAttribute('href') === hash) {
                tab.classList.add('active');
                if (tab.getAttribute('href') === "#"+tab1) {
                    document.getElementById(tab1).style.display = 'flex';
                } else if (tab.getAttribute('href') === "#"+tab2) {
                    document.getElementById(tab2).style.display = 'block';
                } else if (tab.getAttribute('href') === "#"+tab3) {
                    document.getElementById(tab3).style.display = 'block';
                } else if (tab.getAttribute('href') === "#"+tab4) {
                    document.getElementById(tab4).style.display = 'block';
                    statusjs.setStatus();
                }
            }
        });
    } else {
        window.location.hash = '#home';
    }
}