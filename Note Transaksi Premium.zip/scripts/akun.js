import * as hitungjs from './penghitungdata.js';
import * as widget from './widget.js';import * as ruangbawahjs from './ruangbawah.js';
import * as statusjs from './status.js'

const listAkun = document.getElementById('listAkun');

export async function lihatAkun() {
    const status = await hitungjs.lihatStatusAkun();
    listAkun.innerHTML = '';
    status.sort((a,b)=> Math.abs(b.uang)-Math.abs(a.uang));
    status.forEach(item=> {
        let li = widget.buatListSaranPaying(item);
        listAkun.appendChild(li);
    });
    //statusjs.setStatus();
}