
//<div id="toast">This is a toast message!</div>
export function showToast(text) {
    const toast = document.getElementById("toast");
    toast.className = "show";
    toast.innerText = text;
    setTimeout(function(){
        toast.className = toast.className.replace("show", "");
    }, 3000); // Toast akan hilang setelah 3 detik
}