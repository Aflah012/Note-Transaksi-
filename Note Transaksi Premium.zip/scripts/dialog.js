import * as widget from './widget.js';
import * as penambahjs from './penambah.js';
import * as mandat from './keloladata.js';
import * as pembayaranjs from './pembayaran.js';
import * as saran from './saran.js';
import * as produkjs from './produk.js';
import * as ruangbawahjs from './ruangbawah.js';

const hapus = document.getElementById('deleteDialBtn');
const dialogConfirm = document.getElementById('dialogConfirm');
const yesconfirm = document.getElementById('yesconfirm');
const noconfirm = document.getElementById('noconfirm');
const dialog = document.getElementById('dialog');
const btnDialog = document.getElementById('closeDialogBtn');
const editDialBtn = document.getElementById('editDialBtn');
const kategori = document.getElementById('kategoriDialog');
const pembeli = document.getElementById('pembeliDialog');
const waktu = document.getElementById('waktu');

let id = 0;
let pro = [];
let pembayaran = [];
let kumpulanNominal = 0;
let kumpulanPembayaran = 0;

let pamerDC;

const ktgH1 = ruangbawahjs.getKtgH1();

export function getTransaksiId() {
    return id;
}

export function setTransaksiId(i) {
    id = i;
}

export function openDialog(i, kate, pemb, time, produk, pem) {
    const produkDialog = document.getElementById('produkDialog');
    const nominalDialog = document.getElementById('nominalDialog');
    
    dialog.style.display = 'block';

    id = i;
    kategori.innerText = kate;
    pembeli.innerText = pemb;
    waktu.innerText = time;
    pro = produk;
    pembayaran = pem;

    //let kumpulanProduk = '';
    kumpulanNominal = 0;
    kumpulanPembayaran = 0;

    produkDialog.innerHTML = '';
    
    const item = {ktgT: kate, produk: produk, pembayaran: pem};
    const statusli = widget.buatStatusTransaksi(item)
    
    produkDialog.appendChild(statusli);

    pro.forEach(unit => {
        let li = widget.buatListProduk(unit,kate);
        produkDialog.appendChild(li);
        let jB; 
        if(kate === 'Beli') {
            jB = unit.harga;
        } else {
            jB = unit.harga+unit.profit;
        }
        if(unit.ktgH === ktgH1) {
            let jum = widget.setJuml(unit)
            jB = jB*jum;
        }
        kumpulanNominal += jB;
    });
    if(pro.length === 0) {
        let li = document.createElement('li');
        li.textContent = 'Tidak Ada Produk';
        produkDialog.appendChild(li);
    }
    
    pembayaran.forEach(item => {
        let li = widget.buatListPembayaran(item);
        produkDialog.appendChild(li);
        
        kumpulanPembayaran += item.jumlah;
    });
    if(pembayaran.length === 0) {
        let li = document.createElement('li');
        li.textContent = 'Tidak Ada Catatan Pembayaran';
        produkDialog.appendChild(li);
    }
    if(kumpulanNominal < kumpulanPembayaran) {
        kumpulanNominal = kumpulanPembayaran;
    }
    
    nominalDialog.innerText = 'Rp'+ kumpulanNominal.toLocaleString('en-US');
}

export function closeDialog() {
    dialog.style.display = 'none';
}

export function openDialogConfirm(para) {
    dialogConfirm.style.display = 'block';
    pamerDC = para;
}

export function closeDialogConfirm() {
    dialogConfirm.style.display = 'none';
    id = 0;
}

function openPengedit() {
    penambahjs.displayPenambah();
    let [tanggal,
        jam] = waktu.innerText.split(' ');
    let datelo = tanggal.split('/');
    let dateja = datelo[2]+'-'+datelo[1]+'-'+datelo[0];
    penambahjs.setWaktu(jam, dateja);
    nama.textContent = pembeli.innerText;
    //penambahjs.setKtgT(kategori.innerText);
    penambahjs.setKategori(kategori.innerText);
    pembayaranjs.resetPembayaran();
    pembayaranjs.lihatPembayaran(pembayaran);
    produkjs.lihatProduk(pro);
    penambahjs.displayKtgTn(false);
    if(kumpulanPembayaran < kumpulanNominal) {
        saran.bukaSaranPaying();
    }
}

hapus.addEventListener('click', function() {
    openDialogConfirm(mandat.menghapus)
    closeDialog();
});

btnDialog.addEventListener('click', function() {
    closeDialog();
    id = 0;
});
noconfirm.addEventListener('click', closeDialogConfirm);
yesconfirm.addEventListener('click', () => {
    pamerDC();
});
editDialBtn.addEventListener('click', function() {
    openPengedit();
    pembayaranjs.openAndCloseEditPembayaran(false);
    closeDialog();
});

dialog.addEventListener('click', function(event) {
    if (event.target === dialog) {
        closeDialog();
        id = 0;
    }
});
dialogConfirm.addEventListener('click', function(event) {
    if (event.target === dialogConfirm) {
        closeDialogConfirm();
    }
});