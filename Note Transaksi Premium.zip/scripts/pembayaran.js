import * as waktujs from './date.js';
import * as widget from './widget.js';
import * as saran from './saran.js';
import * as penambahjs from './penambah.js';
import * as produkjs from './produk.js';

const closeep = document.getElementById('closeep');
const saveep = document.getElementById('saveep');
const metodepem = document.getElementById('metodepembayaran');
const jumlahpem = document.getElementById('jumlahpembayaran');
const tglpem = document.getElementById('tglpem');
const wktpem = document.getElementById('wktpem');

export let pembayaran = [];
export let pembayaranedit = [];
let idpem = 0;
let idpemba = 0;

export function resetPembayaran() {
    idpemba = 0;
    pembayaran = [];
    pembayaranedit = [];
}

export function getPembayaran() {
    return pembayaran;
}

export function openAndCloseEditPembayaran(syarat,isiEP) {
    const div = document.getElementById('editpembayaran');
    const pembayarann = document.getElementById('pembayaran');
    const li = pembayarann.querySelector('.litmb');
    if(syarat) {
        div.style.display = 'flex';
        li.style.display = 'none';
        if(typeof isiEP === 'function') {
            isiEP();
        }
        jumlahpem.focus();
        saran.closeSuggestions();
    } else {
        div.style.display = 'none';
        li.style.display = 'flex';
    }
}

export function getStatusEP() {
    const div = document.getElementById('editpembayaran');
    if(div.style.display === 'none') {
        return false;
    } else {
        return true;
    }
}

function isiEditPembayaran(id,mp, jp, tp, wp) {
    idpem = id||0;
    metodepem.value = mp||'Uang Tunai';
    jumlahpem.value = jp||'';
    tglpem.value = tp||waktujs.datePick();
    wktpem.value = wp||waktujs.timePick();
}

export function tambahPembayaran() {
    let item = {
        id: idpem,
        metode: metodepem.value,
        jumlah: Number(jumlahpem.value),
        tanggal: tglpem.value,
        waktu: wktpem.value
    };
    if(!item.tanggal) {
        openAndCloseEditPembayaran(false);
        return;
    }
    let same = pembayaranedit.findIndex(o=>o.id === item.id);
    if(same !== -1) {
        pembayaranedit[same] = item;
    } else {
        pembayaranedit.push(item);
    }
    lihatPembayaran(pembayaranedit);
    isiEditPembayaran();
    openAndCloseEditPembayaran(false)
}

function removeItemPem(items, id) {
    const index = items.findIndex(item => item.id === id);
    if (index !== -1) {
        items.splice(index, 1);
    }
}

function setIdPembayaran(edit) {
    let item = [];
    if(edit) {
    for(let i = 0; i < edit.length; i++) {
        if(edit[i].id === 0||!edit[i].id) {
            idpemba++
            item.push({
                id: idpemba,
                metode: edit[i].metode,
                jumlah: edit[i].jumlah,
                tanggal: edit[i].tanggal,
                waktu: edit[i].waktu
            });
        } else {
            item.push(edit[i]);
        }
    }
    }
    return item;
}

function removeIdPembayaran(edit) {
    let item = [];
    for(let i = 0; i < edit.length; i++) {
        if(edit[i].id > 0||edit[i].id) {
            item.push({
                metode: edit[i].metode,
                jumlah: edit[i].jumlah,
                tanggal: edit[i].tanggal,
                waktu: edit[i].waktu
            });
        } else {
            item.push(edit[i]);
        }
    }
    return item;
}

export function lihatPembayaran(pembayarank) {
    pembayaranedit = setIdPembayaran(pembayarank);
    pembayaran = removeIdPembayaran(pembayaranedit);
    const pembayarann = document.getElementById('pembayaran');
    pembayarann.innerHTML = '';
    pembayaranedit.forEach(item => {
        const li = widget.buatListPembayaran(item);
        
        const span = document.createElement('span');
        span.classList.add('closeli');
        span.classList.add('checkpen');
        span.innerHTML = '&times;'
        span.onclick = function(event) {
            event.stopPropagation();
            removeItemPem(pembayaranedit, item.id);
            lihatPembayaran(pembayaranedit);
        }
        let syarat = li.querySelector('.produkspace');
        if (syarat) {
            syarat.parentNode.insertBefore(span, syarat);
        }
        li.onclick = function() {
            openAndCloseEditPembayaran(true,isiEditPembayaran(item.id,item.metode,item.jumlah,item.tanggal,item.waktu));
        }
        pembayarann.appendChild(li);
    });
    
    const tmb = document.createElement('li');
    tmb.classList.add('litmb');
    tmb.textContent = 'Tambah Pembayaran';
    const span = document.createElement('span');
        span.classList.add('btn-saran');
        span.innerHTML = '<img src="icon/edit.png" alt="Icon" width="30" height="30">';
        span.onclick = function(event) {
            event.stopPropagation();
            saran.bukaSaranPaying();
        }
    tmb.appendChild(span);
    tmb.onclick = function() {
        openAndCloseEditPembayaran(true,isiEditPembayaran(''));
    }
    pembayarann.appendChild(tmb);
    produkjs.lihatProduk(produkjs.getProdukFormList());
}

saveep.addEventListener('click', tambahPembayaran)
closeep.addEventListener('click', function() {
        openAndCloseEditPembayaran(false);
});