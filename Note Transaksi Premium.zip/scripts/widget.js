import * as mandat from './keloladata.js';
import * as ruangbawahjs from './ruangbawah.js';

const ktgH1 = ruangbawahjs.getKtgH1();

export function setJuml(unit) {
    let jumlahK;
    if(Array.isArray(unit.jumlah)) {
    jumlahK = 0;
    unit.jumlah.forEach(jm => {
        jumlahK += jm.jml
    })
    }else {
        jumlahK = unit.jumlah;
        let e = {jml: unit.jumlah};
        unit.jumlah = [];
        unit.jumlah.push(e)
    }
    return jumlahK;
}

export function buatListProduk(unit,syarat) {
    const li = document.createElement('li');
    
    let div = document.createElement('div');
    div.classList.add('produkspace');

    let divleft = document.createElement('div');
    divleft.classList.add('produkleft');

    let divnama = document.createElement('div');
    divnama.classList.add('produknama');
    divnama.innerHTML = unit.nama;
    divleft.appendChild(divnama);
    let jumlahK = setJuml(unit);

    let divjumlah = document.createElement('div');
    divjumlah.classList.add('produkjumlah');
    if (unit.satuan === 'Rp') {
        divjumlah.innerHTML = unit.satuan + jumlahK.toLocaleString('en-US');
    } else {
        divjumlah.innerHTML = jumlahK + ' ' + unit.satuan;
    }
    divleft.appendChild(divjumlah);
    

    let divuntung = document.createElement('div');
    let untung = '';
    if(unit.ktgH === ktgH1){
        divuntung.classList.add('produkharga');
        if(syarat === 'Beli') {
            untung = 'Total: Rp'+(unit.harga*jumlahK).toLocaleString('en-US');
        } else {
            untung = 'Total: Rp'+((unit.harga+unit.profit)*jumlahK).toLocaleString('en-US');
        }
    } else {
        divuntung.classList.add('produkprofit');
        untung = (100 / Number(unit.harga) * Number(unit.profit)).toFixed(2) + '%';
    }
    divuntung.innerHTML = untung;
    divleft.appendChild(divuntung);
    div.appendChild(divleft);

    let divright = document.createElement('div');
    divright.classList.add('produkright');

    let divhargajual = document.createElement('div');
    divhargajual.classList.add('produkhargajual');
    divhargajual.innerHTML = 'Rp' + (Number(unit.harga) + Number(unit.profit)).toLocaleString('en-US');
    divright.appendChild(divhargajual);
    div.appendChild(divright);

    let divharga = document.createElement('div');
    divharga.classList.add('produkharga');
    divharga.innerHTML = 'Rp' + unit.harga.toLocaleString('en-US');
    divright.appendChild(divharga);

    let divprofit = document.createElement('div');
    divprofit.classList.add('produkprofit');
    divprofit.innerHTML = 'Rp' + unit.profit.toLocaleString('en-US');
    divright.appendChild(divprofit);

    let divcatatan = document.createElement('div');
    divcatatan.classList.add('produkcatatan');
    if (unit.catatan) {
        divcatatan.innerHTML = unit.catatan;
    }
    li.appendChild(div);
    li.appendChild(divcatatan);

    return li;
}

export function buatListPembayaran(unit) {
    const li = document.createElement('li');
    
    let div = document.createElement('div');
    div.classList.add('produkspace');

    let divleft = document.createElement('div');
    divleft.classList.add('produkleft');

    let divmetode = document.createElement('div');
    divmetode.classList.add('produknama');
    divmetode.innerHTML = unit.metode;
    divleft.appendChild(divmetode);

    let divjumlah = document.createElement('div');
    divjumlah.classList.add('produkprofit');
    divjumlah.innerHTML = 'Rp' + unit.jumlah.toLocaleString('en-US');
    if(unit.jumlah  < 0) {
            divjumlah.style.color = '#ff0222';
        } else {
            divjumlah.style.color = 'lime';
        }
    divleft.appendChild(divjumlah);
    div.appendChild(divleft);
    
    let divright = document.createElement('div');
    divright.classList.add('produkright');
    
    let divwaktu = document.createElement('div');
    divwaktu.classList.add('produkhargajual');
    divwaktu.innerHTML = unit.waktu;
    divright.appendChild(divwaktu);
    
    let divtanggal = document.createElement('div');
    divtanggal.classList.add('produkhargajual');
    divtanggal.innerHTML = mandat.konversiTanggal(unit);
    divright.appendChild(divtanggal);
    
    div.appendChild(divright);
    
    li.appendChild(div)
    return li;
}

export function buatListSaranPaying(unit) {
    const li = document.createElement('li');
    
    let div = document.createElement('div');
    div.classList.add('produkspace');

    let divmetode = document.createElement('div');
    divmetode.classList.add('produknama');
    divmetode.innerHTML = unit.metode||unit.nama;
    if(unit.skor) {
        divmetode.innerHTML = unit.metode+' '+unit.skor;
    }
    div.appendChild(divmetode);

    let divjumlah = document.createElement('div');
    divjumlah.classList.add('produkprofit');
    divjumlah.innerHTML = 'Rp' + Number(unit.jumlah||unit.uang).toLocaleString('en-US');
    if(unit.uang < 0||unit.jumlah  < 0) {
            divjumlah.style.color = '#ff0222';
        } else {
            divjumlah.style.color = 'lime';
        }
    div.appendChild(divjumlah);
    
    li.appendChild(div)
    return li;
}

export function buatStatusTransaksi(unit) {
    const li = document.createElement('li');
    
    let div = document.createElement('div');
    div.classList.add('produkspace');
    
    let divleft = document.createElement('div');
    divleft.classList.add('produkleft');
    
    let jumlahBiaya = 0;
    unit.produk.forEach(item => {
        let jB; 
        if(unit.ktgT && unit.ktgT === 'Beli') {
            jB = item.harga;
        } else {
            jB = item.harga+item.profit;
        }
        if(item.ktgH === ktgH1) {
            let jum = setJuml(item)
            jB = jB*jum;
        }
        jumlahBiaya += jB;
    });
    let divbiaya = document.createElement('div');
    divbiaya.classList.add('produkharga');
    divbiaya.style.color = 'white';
    divbiaya.innerHTML = `Total Biaya:<br><span class="red">Rp${jumlahBiaya.toLocaleString('en-US')}</span>`||'Tidak Ada Catatan Produk';
    divleft.appendChild(divbiaya);
    div.appendChild(divleft);
    
    let divright = document.createElement('div');
    divright.classList.add('produkright');
    
    let jumlahPaying = 0;
    unit.pembayaran.forEach(item => {
        jumlahPaying += item.jumlah;
    });
    let divpaying = document.createElement('div');
    divpaying.classList.add('produkprofit');
    divpaying.style.color = 'white';
    divpaying.innerHTML = `Total Pembayaran:<br>`;
    let spanpaying = document.createElement('span');
    spanpaying.classList.add("produkprofit");
    spanpaying.innerHTML = `Rp${jumlahPaying.toLocaleString('en-US')}`;
    if(jumlahPaying < 0) {
            spanpaying.style.color = '#ff0222';
    } else {
            spanpaying.style.color = 'lime';
    }
    divpaying.appendChild(spanpaying);
    divright.appendChild(divpaying);
    div.appendChild(divright);
    
    let judul = document.createElement('div');
    judul.classList.add('produkprofit');
    judul.style.color = 'white';
    judul.innerHTML = '-----+----StatusTransaksi----+-----';
    li.appendChild(judul);
    
    li.appendChild(div)
    
    let statusPay = jumlahPaying-jumlahBiaya;
    let persenPay = (100/jumlahBiaya*jumlahPaying)||0;
     
    let divSt = document.createElement('div');
    divSt.classList.add('produkprofit');
    //divSt.classList.add('produkspace');
    divSt.style.color = 'white';
    let span = document.createElement('span');
    if(statusPay  < 0) {
        span.style.color = '#ff0222';
    } else {
        span.style.color = 'lime';
    }
    if(statusPay === 0) {
        span.innerHTML = 'Lunas'+`(${persenPay.toFixed(2)}%)`;
    } else {
        span.innerHTML = 'Rp'+statusPay.toLocaleString('en-US')+`(${persenPay.toFixed(2)}%)`;
    }
    divSt.innerHTML = 'Status Pembayaran:<br>';
    divSt.style.marginTop = '7px';
    divSt.appendChild(span);
    li.appendChild(divSt);
    return li;
}

export function listDataTransaksi(item) {
    let li = document.createElement('li');
        li.classList.add('datali');

        let div1 = document.createElement('div');
        div1.classList.add('dataliright');

        let div2 = document.createElement('div');
        div2.classList.add('datalinama');
        div2.innerHTML = item.nama;
        div1.appendChild(div2);

        let div3 = document.createElement('div');
        div3.classList.add('dataliproduk');

        let div = document.createElement('div');
        div.classList.add('datalileft');
        
        let divnominal = document.createElement('div');
        divnominal.classList.add('hargali');
        
        let divwaktu = document.createElement('div');
        divwaktu.classList.add('waktuli');
        divwaktu.innerText = item.waktu;
        //divwaktu.style.

        let hargali = 0;
        let produkli = '';

        item.produk.forEach(unit => {
            produkli += unit.nama+', ';
            let hL;
            if(item.ktgT&& item.ktgT=== 'Beli') {
                hL = Number(unit.harga);
            } else {
                hL = Number(unit.harga) + Number(unit.profit);
            }
            if(unit.ktgH === ktgH1) {
                hL = hL*setJuml(unit);
            }
            hargali -= hL;
        });
        
        item.pembayaran.forEach(unit => {
            hargali += unit.jumlah;
        });
        
        if(hargali < 0) {
            divnominal.style.color = '#ff0222';
        } else {
            divnominal.style.color = 'lime';
        }

        div3.innerHTML = produkli || 'Tidak Ada Produk';
        if(hargali === 0) {
            divnominal.textContent = 'Lunas';
        } else {
            divnominal.textContent = 'Rp'+hargali.toLocaleString('en-US');
        }
        div.appendChild(divnominal);
        div.appendChild(divwaktu);
        
        div1.appendChild(div3);

        li.appendChild(div1);
        li.appendChild(div);
    return li;
}